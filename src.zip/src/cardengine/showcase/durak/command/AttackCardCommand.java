package cardengine.showcase.durak.command;

import cardengine.framework.command.AbstractCommand;
import cardengine.framework.core.Card;
import cardengine.framework.core.CardVisibility;
import cardengine.framework.core.Player;
import cardengine.framework.core.Table;

public class AttackCardCommand extends AbstractCommand {
    private Table table;
    private Card card;

    public AttackCardCommand(Player player, Table table, Card card) {
        super(player);
        this.table = table;
        this.card = card;
    }

    @Override
    public void execute() {
        table.addCard(card.flip());
    }

    @Override
    public void undo() {
        table.removeCard(card);
    }
}
